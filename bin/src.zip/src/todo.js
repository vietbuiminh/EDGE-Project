// TODO: include an IE polyfill for getComputedStyle?
// TODO: review every usage of usedStyleOf vs currentStyleOf