<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Home | Cool QC</title>
<link href="ResponsiveTopNavDropdown.css" rel="stylesheet" type="text/css" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="doubletaptogo.min.js" type="text/javascript"></script>
<!--[if IE]>
	<script src="picturefill.min.js" async="async"></script>
<![endif]-->
<!--[if lt IE 9]>
	<script src="dist/html5shiv.js"></script>
<![endif]-->
</head>

<body>
	<div class="container">
    	
        <header class="site-header">
        	<?php include('includes/header.html'); ?>
        </header>
        
        <section class="stories">
            <header class="three-column-row stories-header">
            	<h2>People</h2>
                <h2>Places</h2>
                <h2>Progress</h2>
            </header>
            
            <div class="three-column-row">
                <article class="story">
                    <p><img src="images/people.jpg" alt="Photo of a young bearded man" /></p>
                    <p>Placeholder text that is trying to resemble the length of a People story that will welcome site visitors. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                    <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>
                </article>
                
                <article class="story">
                    <p><img src="images/places.jpg" alt="Photo of the outside of Analog 2 Arcade Bar in Moline" /></p>
                    <p>Placeholder text that is trying to resemble the length of a Places story that will welcome site visitors. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                    <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>
                </article>
                
                <article class="story">
                    <p><img src="images/progress.jpg" alt="Photo of Montse Ricossa, a young reporter for KWQC Channel 6 in Davenport" /></p>
                    <p>Placeholder text that is trying to resemble the length of a Progress story that will welcome site visitors. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                    <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>
                </article>
            </div>
        </section><!--end stories-->
        
        <section class="about">
        	<aside class="center">
            	<img src="images/about-photo.jpg" alt="Photo of an interview of a Quad Citizen being conducted" />
            </aside>
            <article>
            	<h2>About Us.</h2>
                <p>We are a group of photographers, videographers, Journalists and designers who attend Augustana College. We started this project because we noticed a disconnect between young people and their involvement in the QC community. There are so many people in the QC who are doing so many cool things; taking on projects, opening restaurants, expanding their business, etc- yet the young people in the community don't ever hear about it or know what's going on. We want to change that. At the end of the day, we just want to highlight these cool people and give them the recognition that they deserve; and get young people involved along the way.</p>
            </article>
        </section>
        
        <section class="content-wide center">
        	<p><img src="images/the-gang.jpg" /></p>
        </section>
        
        <section class="readings">
        	<h2>Required Readings.</h2>
            <div class="stories-grid">
            	<aside>
                	<img src="images/article1.jpg" />
                </aside>
                <article>
                	<h3>Article Heading</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit</p>
                    <p><a href="article-one.php" class="button">Read More</a></p>
                </article>
            </div>
            
            <div class="stories-grid">
            	<aside>
                	<img src="images/article1.jpg" />
                </aside>
                <article>
                	<h3>Article Heading</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit</p>
                    <p><a href="article-one.php" class="button">Read More</a></p>
                </article>
            </div>
        </section>
    </div><!--end container-->
<script src="bin/css-polyfills.min.js"></script>
</body>
</html>